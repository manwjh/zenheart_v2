/**
 * Smoke test: spawn zenlink-mcp via stdio and verify tools/list (no real ZenHeart calls).
 * Usage: from zenlink-mcp package root: node scripts/smoke-tools.mjs
 *
 * Expected tool names must stay in sync with `registerTool` in `src/server.ts`.
 */
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const cliJs = join(__dirname, "..", "dist", "cli.js");

/** Canonical list — update when adding/removing MCP tools (sorted lexically). */
const EXPECTED_TOOL_NAMES = Object.freeze(
  [
    "zenlink_ack_messages",
    "zenlink_connect",
    "zenlink_create_room",
    "zenlink_disconnect",
    "zenlink_get_inbox",
    "zenlink_get_inbox_global",
    "zenlink_get_inbox_summary",
    "zenlink_get_room_messages",
    "zenlink_inbound_poll",
    "zenlink_inbound_stats",
    "zenlink_join_room",
    "zenlink_leave_room",
    "zenlink_list_room_members",
    "zenlink_list_rooms_agent",
    "zenlink_list_rooms_history",
    "zenlink_list_rooms_lobby",
    "zenlink_patch_profile",
    "zenlink_send_message",
    "zenlink_send_message_to_all",
    "zenlink_start_long_lived",
    "zenlink_status",
    "zenlink_update_room_allowlist",
  ].sort(),
);

function listsEqual(a, b) {
  return (
    a.length === b.length && a.every((name, i) => name === b[i])
  );
}

const transport = new StdioClientTransport({
  command: process.execPath,
  args: [cliJs],
  env: {
    ...process.env,
    ZENLINK_AGENT_ID:
      process.env.ZENLINK_AGENT_ID ??
      process.env.ZENHEART_AGENT_ID ??
      process.env.ZENHEART_V2_AGENT_ID ??
      "smoke_test_agent",
    ZENLINK_TOKEN:
      process.env.ZENLINK_TOKEN ??
      process.env.ZENHEART_TOKEN ??
      process.env.ZENHEART_V2_TOKEN ??
      "smoke_test_token",
  },
  stderr: "inherit",
});

const client = new Client({ name: "zenlink-mcp-smoke", version: "0.0.1" });

await client.connect(transport);

const { tools } = await client.listTools();
const names = tools.map((t) => t.name).sort();

if (!listsEqual(names, [...EXPECTED_TOOL_NAMES])) {
  console.error(
    "FAIL: tools/list must exactly match the canonical tool set (see EXPECTED_TOOL_NAMES in smoke-tools.mjs).",
  );
  console.error("expected count:", EXPECTED_TOOL_NAMES.length, "got:", names.length);
  console.error("expected:", [...EXPECTED_TOOL_NAMES].join(", "));
  console.error("actual:  ", names.join(", "));
  await transport.close();
  process.exit(1);
}

console.log("PASS: tools/list count =", names.length);
console.log(names.join("\n"));

await transport.close();
