#!/usr/bin/env node
/**
 * Register zenlink-mcp in OpenClaw config (mcp.servers) via CLI.
 *
 * Requires: openclaw on PATH, built dist/cli.js, and agent credentials:
 *   ZENLINK_AGENT_ID + ZENLINK_TOKEN, or ZENHEART_* / ZENHEART_V2_*.
 *
 * Usage:
 *   export ZENLINK_AGENT_ID=...
 *   export ZENLINK_TOKEN=...
 *   npm run openclaw:register
 *
 * Optional env: OPENCLAW_MCP_NAME (default zenheart), ZENLINK_HOST, ZENLINK_USE_TLS,
 * ZENLINK_MCP_WS_TIMEOUT_MS, or ZENHEART_* aliases for host/tls.
 *
 * Upgrade: run `npm run build` in zenlink-mcp (and peer zenlink), then re-run this script
 * to refresh the registered command if the path or env changed; restart OpenClaw.
 */
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const pkgRoot = dirname(scriptDir);
const cliJs = resolve(pkgRoot, "dist", "cli.js");

if (!existsSync(cliJs)) {
  console.error("error: dist/cli.js not found — run: npm run build");
  process.exit(1);
}

const agentId =
  process.env.ZENLINK_AGENT_ID ??
  process.env.ZENHEART_AGENT_ID ??
  process.env.ZENHEART_V2_AGENT_ID;
const token =
  process.env.ZENLINK_TOKEN ??
  process.env.ZENHEART_TOKEN ??
  process.env.ZENHEART_V2_TOKEN;

if (!agentId || !token) {
  console.error(
    "error: set ZENLINK_AGENT_ID and ZENLINK_TOKEN, or ZENHEART_* / ZENHEART_V2_*",
  );
  process.exit(1);
}

const env = { ZENLINK_AGENT_ID: agentId, ZENLINK_TOKEN: token };

for (const k of [
  "ZENLINK_HOST",
  "ZENLINK_USE_TLS",
  "ZENLINK_MCP_WS_TIMEOUT_MS",
  "ZENHEART_HOST",
  "ZENHEART_USE_TLS",
  "ZENHEART_V2_HOST",
  "ZENHEART_V2_USE_TLS",
]) {
  const v = process.env[k];
  if (v !== undefined && v !== "") {
    env[k] = v;
  }
}

const spec = {
  command: process.execPath,
  args: [cliJs],
  env,
};

const name = process.env.OPENCLAW_MCP_NAME ?? "zenheart";
const payload = JSON.stringify(spec);

const result = spawnSync("openclaw", ["mcp", "set", name, payload], {
  stdio: "inherit",
});

if (result.error) {
  if ("code" in result.error && result.error.code === "ENOENT") {
    console.error(
      "error: openclaw not found in PATH.\n\nPaste under mcp.servers in ~/.openclaw/openclaw.json:\n",
    );
    const snippet = { mcp: { servers: { [name]: spec } } };
    console.log(JSON.stringify(snippet, null, 2));
    process.exit(1);
  }
  console.error(result.error);
  process.exit(1);
}

process.exit(result.status ?? 0);
