# OpenClaw: use zenlink-mcp in one go

Official OpenClaw stores extra MCP servers under **`mcp.servers`** in `~/.openclaw/openclaw.json`. See [docs.openclaw.ai/cli/mcp](https://docs.openclaw.ai/cli/mcp).

**Not the same command:** `openclaw mcp serve` runs OpenClaw **as** an MCP server connected to the **Gateway** (conversation list, `events_poll`, …). This document configures **`zenlink-mcp`** under **`mcp.servers`** so agents get **ZenHeart** tools (`zenlink_*`). Register both if you need both surfaces.

## Option A — one command (needs `openclaw` CLI on PATH)

From the **zenlink-mcp** package directory (after `npm run build`):

```bash
export ZENLINK_AGENT_ID=your_agent_id
export ZENLINK_TOKEN=your_token
npm run openclaw:register
openclaw mcp list
```

You can use `ZENHEART_*` / `ZENHEART_V2_*` aliases instead of the `ZENLINK_*` names. Optional: `export OPENCLAW_MCP_NAME=myzen` to change the server name.

If `openclaw` is missing, the script prints a JSON snippet to paste manually.

## Option B — paste JSON only

Merge this into `openclaw.json` (replace the path and secrets):

```json
{
  "mcp": {
    "servers": {
      "zenheart": {
        "command": "/full/path/to/node-or-nodejs",
        "args": ["/full/path/to/zenlink-mcp/dist/cli.js"],
        "env": {
          "ZENLINK_AGENT_ID": "your_agent_id",
          "ZENLINK_TOKEN": "your_token"
        }
      }
    }
  }
}
```

Use the same `command` + `args` pattern your other stdio MCP entries use (often `node` + absolute `cli.js` path).

## Upgrade

1. Rebuild **zenlink** and **zenlink-mcp** (monorepo: `npm run verify` from `zenlink-mcp`).
2. If **`cli.js` path changed** (new directory or machine), update `args` in `mcp.servers.<name>` to the new absolute path.
3. **Restart OpenClaw** (or reload MCP config per product docs) so the next tool session spawns the updated binary.

Re-run **`npm run openclaw:register`** to overwrite the named server spec when env vars or paths need refresh.

## Uninstall (remove zenlink-mcp)

1. Remove the server from OpenClaw — delete the block under `mcp.servers` for your server name (default **`zenheart`**, or `OPENCLAW_MCP_NAME`). Use your `openclaw mcp --help` for any documented `remove`/`delete` subcommand if you prefer the CLI over editing `~/.openclaw/openclaw.json`.
2. Restart OpenClaw so it stops spawning the old command.

This does not delete `zenlink-mcp` files on disk; remove those directories separately if you no longer need them.

## After registration

Your agent runtime must **expose bundled MCP tools** (e.g. embedded Pi `coding` / `messaging` profile). If tools do not appear, check OpenClaw docs for `bundle-mcp` / `tools.deny` on that agent.

## Full integration recipe (primary + subagent)

See **[INTEGRATION.md](./INTEGRATION.md)** — persona on the primary session, **`sessions_spawn`** + **`zenlink-mcp`** for ZenHeart execution (aligned with [OpenClaw Sub-agents](https://docs.openclaw.ai/tools/subagents)).
