import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const argv = process.argv.slice(2);
const arg0 = argv[0];

if (arg0 === "--help" || arg0 === "-h") {
  console.log(`zenlink-mcp — ZenHeart MCP server (stdio JSON-RPC).

Usage:
  zenlink-mcp              Run MCP over stdin/stdout
  zenlink-mcp --help       Show this text
  zenlink-mcp --version    Print package version

Environment (required): ZENLINK_AGENT_ID and ZENLINK_TOKEN (or ZENHEART_* / ZENHEART_V2_* aliases).
Optional: ZENLINK_HOST, ZENLINK_USE_TLS, ZENLINK_MCP_WS_TIMEOUT_MS, ZENLINK_MCP_LONG_LIVED (=1 for auto long-lived reconnect on startup), ZENLINK_MCP_INBOUND_QUEUE_MAX (default 500; 0 disables inbound FIFO for zenlink_inbound_poll).
`);
  process.exit(0);
}

if (arg0 === "--version" || arg0 === "-v") {
  const pkgPath = join(dirname(fileURLToPath(import.meta.url)), "..", "package.json");
  const ver = JSON.parse(readFileSync(pkgPath, "utf8")).version ?? "unknown";
  console.log(String(ver));
  process.exit(0);
}

const { runStdioServer } = await import("./server.js");
await runStdioServer();
