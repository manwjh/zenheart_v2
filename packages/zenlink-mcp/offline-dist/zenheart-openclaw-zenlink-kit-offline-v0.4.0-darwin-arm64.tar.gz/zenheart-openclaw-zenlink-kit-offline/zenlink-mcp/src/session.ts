import {
  ZenlinkManagedConnection,
  createZenlinkManagedFromEnv,
  type ZenlinkClient,
  type AuthOkFrame,
  type JsonFrame,
} from "zenlink";

function readWsWaitTimeoutMs(): number {
  const raw = process.env["ZENLINK_MCP_WS_TIMEOUT_MS"];
  if (raw === undefined || raw === "") {
    return 30_000;
  }
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) {
    throw new Error(
      "ZENLINK_MCP_WS_TIMEOUT_MS must be a positive number when set",
    );
  }
  return n;
}

function readLongLivedAutostart(): boolean {
  const v = process.env["ZENLINK_MCP_LONG_LIVED"];
  if (v === undefined || v === "") {
    return false;
  }
  return v === "1" || v.toLowerCase() === "true";
}

/** Max buffered inbound WS frames for {@link ZenlinkSession.inboundPoll}. When queue is full, oldest frames are dropped. */
function readInboundQueueMax(): number {
  const raw = process.env["ZENLINK_MCP_INBOUND_QUEUE_MAX"];
  if (raw === undefined || raw === "") {
    return 500;
  }
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) {
    throw new Error(
      "ZENLINK_MCP_INBOUND_QUEUE_MAX must be a non-negative integer when set",
    );
  }
  return Math.floor(n);
}

type PendingWait = {
  accept: (f: JsonFrame) => boolean;
  resolve: (f: JsonFrame) => void;
  reject: (err: Error) => void;
  timer: ReturnType<typeof setTimeout>;
};

/**
 * Single ZenlinkClient (via {@link ZenlinkManagedConnection}), serialized WebSocket commands,
 * and one in-flight response wait (rooms_list, room_members_list, etc.).
 *
 * Inbound frames that are not consumed by the active `wsRpc` wait (including when there is no wait)
 * are appended to an FIFO queue (bounded by {@link readInboundQueueMax}) for {@link inboundPoll}.
 *
 * After an idle disconnect, the next tool call reconnects via {@link ZenlinkManagedConnection.awaitOnline}
 * ({@link ensureConnected}). With long-lived mode, reconnect uses backoff until {@link disconnect}.
 * Unexpected close during an in-flight `wsRpc` rejects the wait immediately (`onClose`), instead of
 * waiting for the generic timeout.
 */
export class ZenlinkSession {
  private readonly managed: ZenlinkManagedConnection;
  readonly client: ZenlinkClient;
  private readonly wsWaitTimeoutMs: number;
  private readonly inboundQueueMax: number;
  private overflowDroppedTotal = 0;
  private inboundQueue: JsonFrame[] = [];
  private tail: Promise<unknown> = Promise.resolve();
  private pending: PendingWait | null = null;

  constructor() {
    this.wsWaitTimeoutMs = readWsWaitTimeoutMs();
    this.inboundQueueMax = readInboundQueueMax();
    this.managed = createZenlinkManagedFromEnv({
      onMessage: (frame) => this.onFrame(frame),
      onClose: () => {
        this.abortPendingWait(
          new Error("zenlink-mcp: WebSocket closed before response"),
        );
      },
      onAuthFailure: (err) => {
        console.error(`zenlink-mcp: long-lived auth failed: ${err.message}`);
      },
    });
    this.client = this.managed.client;
    if (readLongLivedAutostart()) {
      this.managed.startLongLived();
    }
  }

  status(): {
    connected: boolean;
    longLived: boolean;
    agentId: string;
    host: string;
  } {
    return {
      connected: this.client.isConnected(),
      longLived: this.managed.isLongLivedEnabled(),
      agentId: this.client.agentId,
      host: this.client.host,
    };
  }

  startLongLived(): void {
    this.managed.startLongLived();
  }

  private onFrame(frame: JsonFrame): void {
    const p = this.pending;
    const t = frame.type;

    if (p) {
      if (t === "error") {
        const reason =
          typeof frame["reason"] === "string" ? frame["reason"] : "error";
        const detailRaw = frame["detail"];
        const detail =
          typeof detailRaw === "string" ? `: ${detailRaw}` : "";
        this.abortPendingWait(new Error(`zenlink: ${reason}${detail}`));
        return;
      }
      if (t === "superseded") {
        this.abortPendingWait(new Error("zenlink: connection superseded"));
        return;
      }
      if (p.accept(frame)) {
        p.resolve(frame);
        return;
      }
    }

    this.maybeEnqueueInbound(frame);
  }

  /** Server `ping` is answered inside {@link ZenlinkClient}; omit from poll noise. */
  private shouldSkipInbound(frame: JsonFrame): boolean {
    return frame.type === "ping";
  }

  private maybeEnqueueInbound(frame: JsonFrame): void {
    if (this.inboundQueueMax === 0) {
      return;
    }
    if (this.shouldSkipInbound(frame)) {
      return;
    }
    if (this.inboundQueue.length >= this.inboundQueueMax) {
      this.inboundQueue.shift();
      this.overflowDroppedTotal += 1;
    }
    this.inboundQueue.push(frame);
  }

  /**
   * Remove up to `limit` inbound frames (oldest first). Does not reset overflow counter.
   */
  inboundPoll(limit: number): {
    frames: JsonFrame[];
    remaining: number;
    overflow_dropped_total: number;
  } {
    const cap = Math.min(Math.max(1, limit), 500);
    const frames = this.inboundQueue.splice(0, cap);
    return {
      frames,
      remaining: this.inboundQueue.length,
      overflow_dropped_total: this.overflowDroppedTotal,
    };
  }

  inboundStats(): {
    queued: number;
    overflow_dropped_total: number;
    queue_max: number;
    inbound_poll_disabled: boolean;
  } {
    return {
      queued: this.inboundQueue.length,
      overflow_dropped_total: this.overflowDroppedTotal,
      queue_max: this.inboundQueueMax,
      inbound_poll_disabled: this.inboundQueueMax === 0,
    };
  }

  private clearInboundQueue(): void {
    this.inboundQueue.length = 0;
    this.overflowDroppedTotal = 0;
  }

  private abortPendingWait(err: Error): void {
    const p = this.pending;
    if (!p) {
      return;
    }
    clearTimeout(p.timer);
    this.pending = null;
    p.reject(err);
  }

  private cancelWait(): void {
    this.abortPendingWait(
      new Error("zenlink-mcp: WebSocket response wait cancelled"),
    );
  }

  private beginWait(
    describe: string,
    accept: (f: JsonFrame) => boolean,
  ): Promise<JsonFrame> {
    if (this.pending) {
      return Promise.reject(
        new Error(
          "zenlink-mcp: overlapping WebSocket response waits (serialize tool calls)",
        ),
      );
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const cur = this.pending;
        if (!cur || cur.timer !== timer) {
          return;
        }
        this.pending = null;
        cur.reject(
          new Error(
            `timeout waiting for ${describe} (${this.wsWaitTimeoutMs}ms)`,
          ),
        );
      }, this.wsWaitTimeoutMs);
      this.pending = {
        accept,
        resolve: (f) => {
          clearTimeout(timer);
          this.pending = null;
          resolve(f);
        },
        reject: (err) => {
          clearTimeout(timer);
          this.pending = null;
          reject(err);
        },
        timer,
      };
    });
  }

  private withLock<T>(fn: () => Promise<T>): Promise<T> {
    const next = this.tail.then(fn);
    this.tail = next.then(
      () => undefined,
      () => undefined,
    );
    return next;
  }

  async connect(): Promise<AuthOkFrame> {
    return this.withLock(async () => {
      this.clearInboundQueue();
      return this.managed.connect();
    });
  }

  async disconnect(): Promise<void> {
    return this.withLock(async () => {
      this.cancelWait();
      this.clearInboundQueue();
      this.managed.disconnect();
    });
  }

  private async ensureConnected(): Promise<void> {
    if (!this.client.isConnected()) {
      await this.managed.awaitOnline(this.wsWaitTimeoutMs);
    }
  }

  /**
   * Send a WS request and wait for the first matching inbound frame (by type names),
   * or use `accept` to match (e.g. own `message` echo).
   * Server `error` / `superseded` rejects the wait immediately.
   */
  async wsRpc(
    expectedTypesOrAccept:
      | string[]
      | ((f: JsonFrame) => boolean),
    send: () => void,
  ): Promise<JsonFrame> {
    const describe = Array.isArray(expectedTypesOrAccept)
      ? `frame type(s): ${expectedTypesOrAccept.join(", ")}`
      : "predicate match";
    const accept = Array.isArray(expectedTypesOrAccept)
      ? (f: JsonFrame) =>
          typeof f.type === "string" &&
          expectedTypesOrAccept.includes(f.type)
      : expectedTypesOrAccept;

    return this.withLock(async () => {
      await this.ensureConnected();
      const waitPromise = this.beginWait(describe, accept);
      try {
        send();
      } catch (e) {
        this.cancelWait();
        throw e;
      }
      return waitPromise;
    });
  }
}
