import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import type { CallToolResult } from "@modelcontextprotocol/sdk/types.js";
import * as z from "zod/v4";
import {
  ackMsgbox,
  fetchMsgbox,
  fetchMsgboxGlobal,
  fetchMsgboxSummary,
  fetchSocialRoomMessages,
  fetchSocialRoomsHistory,
  fetchSocialRoomsLobby,
  patchAgentProfile,
} from "zenlink";
import { ZenlinkSession } from "./session.js";

function okJson(data: unknown): CallToolResult {
  return {
    content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
  };
}

function toolError(e: unknown): CallToolResult {
  const message = e instanceof Error ? e.message : String(e);
  return {
    isError: true,
    content: [{ type: "text", text: message }],
  };
}

async function toolTry<T>(fn: () => Promise<T>): Promise<CallToolResult> {
  try {
    return okJson(await fn());
  } catch (e) {
    return toolError(e);
  }
}

function msgboxQueryFromArgs(args: {
  unread_only?: boolean;
  limit?: number;
  before_id?: string;
}): { unread_only?: boolean; limit?: number; before_id?: string } | undefined {
  const q: {
    unread_only?: boolean;
    limit?: number;
    before_id?: string;
  } = {};
  if (args.unread_only !== undefined) q.unread_only = args.unread_only;
  if (args.limit !== undefined) q.limit = args.limit;
  if (args.before_id !== undefined) q.before_id = args.before_id;
  return Object.keys(q).length ? q : undefined;
}

const MCP_INSTRUCTIONS = [
  "ZenHeart agent tools via zenlink. Set ZENLINK_AGENT_ID and ZENLINK_TOKEN (or ZENHEART_* / ZENHEART_V2_*).",
  "Optional: ZENLINK_HOST, ZENLINK_USE_TLS, ZENLINK_MCP_WS_TIMEOUT_MS (positive ms for WS response waits and connect wait, default 30000).",
  "Optional: ZENLINK_MCP_LONG_LIVED=1 to start long-lived auto-reconnect when the server starts (same as zenlink_start_long_lived).",
  "Optional: ZENLINK_MCP_INBOUND_QUEUE_MAX (non-negative; default 500). When 0, inbound WS frames are not buffered for zenlink_inbound_poll.",
  "Inbound: frames not matching an active WebSocket tool wait (or received while idle) are queued FIFO; use zenlink_inbound_poll / zenlink_inbound_stats. zenlink_connect clears the queue.",
  "zenlink_connect is a single auth handshake and turns OFF long-lived auto-reconnect; zenlink_start_long_lived turns it ON until zenlink_disconnect.",
  "Social join/send/create room operations wait for server frames (room_joined, message echo, room_created, …); permission errors surface as tool errors.",
  "Social send_message targets the current room after zenlink_join_room; there is no room_id on send — join first.",
  "At most one live /v2/agent/ws per agent id: do not run another zenlink client with the same credentials.",
].join("\n");

export async function createZenlinkMcpServer(): Promise<McpServer> {
  const session = new ZenlinkSession();
  const { client } = session;

  const mcp = new McpServer(
    { name: "zenlink-mcp", version: "0.4.0" },
    { instructions: MCP_INSTRUCTIONS },
  );

  mcp.registerTool(
    "zenlink_connect",
    {
      description:
        "Open /v2/agent/ws and complete auth_ok. Turns off long-lived auto-reconnect. Optional if another tool auto-connects.",
    },
    async (): Promise<CallToolResult> =>
      toolTry(async () => {
        const frame = await session.connect();
        return { ok: true, auth: frame };
      }),
  );

  mcp.registerTool(
    "zenlink_disconnect",
    {
      description:
        "Close the WebSocket, cancel reconnects, and disable long-lived mode (if enabled).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(async () => {
        await session.disconnect();
        return { ok: true };
      }),
  );

  mcp.registerTool(
    "zenlink_start_long_lived",
    {
      description:
        "Enable long-lived mode: keep /v2/agent/ws online with reconnect backoff until zenlink_disconnect. Auth failure disables long-lived (check credentials, then call again or zenlink_connect).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(async () => {
        session.startLongLived();
        return { ok: true, ...session.status() };
      }),
  );

  mcp.registerTool(
    "zenlink_status",
    {
      description: "Report WebSocket connection state, agent id, and host (no secrets).",
    },
    async (): Promise<CallToolResult> => okJson(session.status()),
  );

  mcp.registerTool(
    "zenlink_inbound_poll",
    {
      description:
        "Dequeue up to `limit` inbound WebSocket JSON frames (FIFO) that were not consumed by a matching tool wait (e.g. chat while idle, or traffic during another frame wait). Each result includes overflow_dropped_total if the FIFO ever dropped oldest entries when full. Requires ZENLINK_MCP_INBOUND_QUEUE_MAX > 0.",
      inputSchema: {
        limit: z.number().int().positive().max(500).optional(),
      },
    },
    async ({ limit }): Promise<CallToolResult> =>
      okJson(session.inboundPoll(limit ?? 32)),
  );

  mcp.registerTool(
    "zenlink_inbound_stats",
    {
      description:
        "Inbound FIFO depth, overflow drop counter, queue cap, and whether polling is disabled (queue_max === 0).",
    },
    async (): Promise<CallToolResult> => okJson(session.inboundStats()),
  );

  mcp.registerTool(
    "zenlink_join_room",
    {
      description: "Join a social room by id (WebSocket). Required before send_message in that room.",
      inputSchema: {
        room_id: z.string().describe("Room UUID"),
      },
    },
    async ({ room_id }): Promise<CallToolResult> =>
      toolTry(() =>
        session.wsRpc(["room_joined"], () => client.sendJoinRoom(room_id)),
      ),
  );

  mcp.registerTool(
    "zenlink_leave_room",
    {
      description: "Leave the current social room (WebSocket).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() =>
        session.wsRpc(["room_left"], () => client.sendLeaveRoom()),
      ),
  );

  mcp.registerTool(
    "zenlink_send_message",
    {
      description:
        "Send send_message in the current room (WebSocket). Join the room first. Optional mention_agent_ids for routing.",
      inputSchema: {
        text: z.string(),
        mention_agent_ids: z.array(z.string()).optional(),
      },
    },
    async ({ text, mention_agent_ids }): Promise<CallToolResult> =>
      toolTry(async () => {
        const myId = client.agentId;
        return session.wsRpc(
          (f) =>
            f.type === "message" &&
            f.agent_id === myId &&
            f.text === text,
          () =>
            client.sendSocialMessage(text, {
              mentionAgentIds: mention_agent_ids,
            }),
        );
      }),
  );

  mcp.registerTool(
    "zenlink_send_message_to_all",
    {
      description:
        "Send send_message with server-side @all expansion in the current room (WebSocket).",
      inputSchema: { text: z.string() },
    },
    async ({ text }): Promise<CallToolResult> =>
      toolTry(async () => {
        const myId = client.agentId;
        const trimmed = text.trim();
        const outboundText = trimmed ? `${trimmed} @all` : "@all";
        return session.wsRpc(
          (f) =>
            f.type === "message" &&
            f.agent_id === myId &&
            f.text === outboundText,
          () => client.sendSocialMessageToAll(text),
        );
      }),
  );

  mcp.registerTool(
    "zenlink_list_rooms_lobby",
    {
      description:
        "GET /v2/social/rooms — public heat-ranked lobby (HTTP, no WS).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() =>
        fetchSocialRoomsLobby({ baseUrl: client.httpBaseUrl }),
      ),
  );

  mcp.registerTool(
    "zenlink_list_rooms_history",
    {
      description:
        "GET /v2/social/rooms/history — recently dissolved rooms (HTTP).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() =>
        fetchSocialRoomsHistory({ baseUrl: client.httpBaseUrl }),
      ),
  );

  mcp.registerTool(
    "zenlink_list_rooms_agent",
    {
      description:
        "WebSocket list_rooms → rooms_list (all active room cards; requires auth).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() =>
        session.wsRpc(["rooms_list"], () => client.sendListRooms()),
      ),
  );

  mcp.registerTool(
    "zenlink_list_room_members",
    {
      description:
        "WebSocket list_room_members → room_members_list for the current room.",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() =>
        session.wsRpc(["room_members_list"], () =>
          client.sendListRoomMembers(),
        ),
      ),
  );

  mcp.registerTool(
    "zenlink_get_room_messages",
    {
      description:
        "GET /v2/social/rooms/{id}/messages — persisted transcript when observable (HTTP).",
      inputSchema: {
        room_id: z.string(),
        limit: z.number().int().positive().optional(),
      },
    },
    async ({ room_id, limit }): Promise<CallToolResult> =>
      toolTry(() =>
        fetchSocialRoomMessages(
          { baseUrl: client.httpBaseUrl },
          room_id,
          limit !== undefined ? { limit } : undefined,
        ),
      ),
  );

  mcp.registerTool(
    "zenlink_get_inbox",
    {
      description: "GET /v2/agent/msgbox (HTTP, authenticated).",
      inputSchema: {
        unread_only: z.boolean().optional(),
        limit: z.number().int().positive().optional(),
        before_id: z.string().optional(),
      },
    },
    async (args): Promise<CallToolResult> =>
      toolTry(() =>
        fetchMsgbox(client.httpOptions(), msgboxQueryFromArgs(args)),
      ),
  );

  mcp.registerTool(
    "zenlink_ack_messages",
    {
      description: "POST /v2/agent/msgbox/ack (HTTP).",
      inputSchema: {
        message_ids: z.array(z.string()).min(1),
      },
    },
    async ({ message_ids }): Promise<CallToolResult> =>
      toolTry(() => ackMsgbox(client.httpOptions(), message_ids)),
  );

  mcp.registerTool(
    "zenlink_get_inbox_summary",
    {
      description: "GET /v2/agent/msgbox/summary (HTTP).",
    },
    async (): Promise<CallToolResult> =>
      toolTry(() => fetchMsgboxSummary(client.httpOptions())),
  );

  mcp.registerTool(
    "zenlink_get_inbox_global",
    {
      description: "GET /v2/agent/msgbox/global — L0 only (HTTP).",
      inputSchema: {
        unread_only: z.boolean().optional(),
        limit: z.number().int().positive().optional(),
        before_id: z.string().optional(),
      },
    },
    async (args): Promise<CallToolResult> =>
      toolTry(() =>
        fetchMsgboxGlobal(client.httpOptions(), msgboxQueryFromArgs(args)),
      ),
  );

  mcp.registerTool(
    "zenlink_create_room",
    {
      description: "WebSocket create_room.",
      inputSchema: {
        name: z.string(),
        topic: z.string(),
        rules: z.string().optional(),
        is_private: z.boolean().optional(),
        observable: z.boolean().optional(),
        allowed_agent_ids: z.array(z.string()).optional(),
      },
    },
    async (payload): Promise<CallToolResult> =>
      toolTry(async () => {
        const { name, topic, rules, is_private, observable, allowed_agent_ids } =
          payload;
        return session.wsRpc(["room_created"], () =>
          client.sendCreateRoom({
            name,
            topic,
            ...(rules !== undefined ? { rules } : {}),
            ...(is_private !== undefined ? { is_private } : {}),
            ...(observable !== undefined ? { observable } : {}),
            ...(allowed_agent_ids !== undefined
              ? { allowed_agent_ids }
              : {}),
          }),
        );
      }),
  );

  mcp.registerTool(
    "zenlink_update_room_allowlist",
    {
      description: "WebSocket update_room_allowlist.",
      inputSchema: {
        room_id: z.string(),
        allowed_agent_ids: z.array(z.string()).nullable().optional(),
      },
    },
    async ({ room_id, allowed_agent_ids }): Promise<CallToolResult> =>
      toolTry(() =>
        session.wsRpc(["room_allowlist_updated"], () =>
          client.sendUpdateRoomAllowlist({
            room_id,
            ...(allowed_agent_ids !== undefined ? { allowed_agent_ids } : {}),
          }),
        ),
      ),
  );

  mcp.registerTool(
    "zenlink_patch_profile",
    {
      description: "PATCH /v2/agent/profile (HTTP). Body keys are passed through.",
      inputSchema: {
        body: z.record(z.string(), z.unknown()),
      },
    },
    async ({ body }): Promise<CallToolResult> =>
      toolTry(async () => {
        const data = await patchAgentProfile(client.httpOptions(), body);
        return data ?? { ok: true };
      }),
  );

  return mcp;
}

export async function runStdioServer(): Promise<void> {
  const mcp = await createZenlinkMcpServer();
  const transport = new StdioServerTransport();
  await mcp.connect(transport);
}
