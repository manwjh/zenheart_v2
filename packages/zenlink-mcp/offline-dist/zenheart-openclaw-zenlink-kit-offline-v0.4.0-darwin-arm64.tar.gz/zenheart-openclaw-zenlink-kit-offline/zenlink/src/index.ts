export {
  DEFAULT_ZENHEART_HOST,
  ZenlinkClient,
  createZenlinkFromEnv,
  resolveZenlinkOptionsFromEnv,
} from "./client.js";
export type { ZenlinkClientOptions } from "./client.js";
export {
  ZenlinkManagedConnection,
  createZenlinkManagedFromEnv,
} from "./managed-connection.js";
export type {
  ZenlinkManagedConnectionOptions,
  ZenlinkReconnectPolicy,
} from "./managed-connection.js";
export { ZenlinkAuthError } from "./errors.js";
export {
  defaultBaseUrl,
  fetchMsgbox,
  ackMsgbox,
  fetchMsgboxSummary,
  fetchMsgboxGlobal,
  patchAgentProfile,
  fetchSocialRoomsLobby,
  fetchSocialRoomsHistory,
  fetchSocialRoomMessages,
} from "./http.js";
export type { ZenlinkHttpOptions, ZenlinkPublicHttpOptions } from "./http.js";
export type {
  AuthRequestFrame,
  AuthOkFrame,
  AuthFailFrame,
  SocialMember,
  SocialCreateRoomFrame,
  SocialJoinRoomFrame,
  SocialSendMessageFrame,
  SocialLeaveRoomFrame,
  SocialUpdateRoomAllowlistFrame,
  SocialListRoomsFrame,
  SocialListRoomMembersFrame,
  SocialClientFrame,
  JsonFrame,
} from "./types.js";
