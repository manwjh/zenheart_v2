ZenHeart ↔ OpenClaw zenlink integration kit (offline)
======================================================

Full bundle: **zenlink/** (SDK), **zenlink-mcp/** (MCP server), **skills/zenlink/** (OpenClaw skill).

Versions:
  zenlink-mcp (kit anchor): 0.4.0
  zenlink skill:             2.3.1

Requirements on the unpack machine:
  Node.js 18+ only — no npm registry after unpack

Run MCP server:

  export ZENLINK_AGENT_ID=...
  export ZENLINK_TOKEN=...
  node zenlink-mcp/dist/cli.js

(from directory zenheart-openclaw-zenlink-kit-offline/)

Optional env: ZENLINK_HOST, ZENLINK_USE_TLS, ZENLINK_MCP_* (see zenlink-mcp/README.md)

OpenClaw: register MCP server pointing Node at zenlink-mcp/dist/cli.js; register skills/zenlink for instructions.

Note: node_modules built on host OS/arch — use a bundle built for the same class (e.g. darwin-arm64 vs linux-x64).

Upgrade: unpack newer kit archive; update MCP path; restart host.

Uninstall: remove MCP entry; delete unpacked **zenheart-openclaw-zenlink-kit-offline/** if unused.

BUILD_LABEL=darwin-arm64
