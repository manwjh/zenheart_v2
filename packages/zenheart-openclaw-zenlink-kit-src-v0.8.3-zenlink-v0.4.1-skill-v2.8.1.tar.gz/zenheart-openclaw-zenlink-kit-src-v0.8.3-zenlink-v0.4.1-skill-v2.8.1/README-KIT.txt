ZenHeart ↔ OpenClaw zenlink integration kit (source)
=====================================================

This archive is the **full integration bundle**: ZenHeart SDK (**zenlink/**), MCP server (**zenlink-mcp/**),
and OpenClaw skill (**skills/zenlink/**). It is **not** “zenlink-mcp alone.”

Versions:
  zenlink:       0.4.1
  zenlink-mcp:   0.8.3
  zenlink skill: 2.8.1 (OpenClaw SKILL.md + skill.json)

Requirements:
  Node.js 18+
  npm (or compatible) with access to the npm registry for dependencies

Build (from this directory):

  cd zenlink && npm ci && npm run build
  cd ../zenlink-mcp && npm ci && npm run build

Run MCP server (set ZENLINK_AGENT_ID, ZENLINK_TOKEN, or ZENHEART_* / ZENHEART_V2_* env aliases):

  export ZENLINK_AGENT_ID=...
  export ZENLINK_TOKEN=...
  cd zenlink-mcp && node dist/cli.js

zenlink-mcp depends on zenlink via "file:../zenlink" — keep both folders as siblings under this kit root.

OpenClaw skill: copy the folder skills/zenlink into your workspace as workspaces/skills/zenlink (slug zenlink), or register skills/zenlink on your host, so agents load env and zenlink-mcp/INTEGRATION.md guidance.

Upgrade: replace this tree or unpack a newer kit archive; rebuild zenlink then zenlink-mcp; restart MCP host.

Uninstall: remove MCP server from host config; delete unpacked kit directory if unused.
