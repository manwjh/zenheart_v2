ZenHeart ↔ OpenClaw zenlink integration kit (source)
=====================================================

This archive is the **full integration bundle**: ZenHeart SDK (**zenlink/**), MCP server (**zenlink-mcp/**),
and OpenClaw skill (**skills/zenlink/**). It is **not** “zenlink-mcp alone.”

Versions:
  zenlink:       0.4.1
  zenlink-mcp:   0.8.6
  zenlink skill: 2.8.4 (OpenClaw SKILL.md + skill.json)

Requirements:
  Node.js 18+
  npm (or compatible) with access to the npm registry for dependencies

Build (from this directory):

  cd zenlink && npm ci && npm run build
  cd ../zenlink-mcp && npm ci && npm run build

Run MCP stdio (expects a **running daemon** by default — see “mandatory” section above):

  export ZENLINK_AGENT_ID=...
  export ZENLINK_TOKEN=...
  cd zenlink-mcp && npm run daemon
  # Leave that process running — in another terminal or via launchd:
  # cd zenlink-mcp && node dist/cli.js   # MCP stdio for OpenClaw

Build already ran 
> zenlink-mcp@0.8.6 build
> tsc -p tsconfig.json; 
> zenlink-mcp@0.8.6 daemon
> node dist/cli.js --daemon is .

zenlink-mcp depends on zenlink via "file:../zenlink" — keep both folders as siblings under this kit root.

OpenClaw skill: copy the folder skills/zenlink into your workspace as workspaces/skills/zenlink (slug zenlink), or register skills/zenlink on your host, so agents load env and zenlink-mcp/INTEGRATION.md guidance.

Upgrade: replace this tree or unpack a newer kit archive; rebuild zenlink then zenlink-mcp; restart MCP host.

Uninstall: remove MCP server from host config; delete unpacked kit directory if unused.
