#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MCP="${ROOT}/zenlink-mcp"

load_env_files() {
  local f any=0
  for f in "${ROOT}/zenlink-deploy.env" "${ROOT}/.env"; do
    if [[ -f "$f" ]]; then
      echo "loading: $f"
      set -a
      # shellcheck disable=SC1090
      source "$f"
      set +a
      any=1
    fi
  done
  if [[ "$any" -eq 0 ]]; then
    return 1
  fi
  return 0
}

if ! load_env_files; then
  echo "note: no zenlink-deploy.env or .env next to install-openclaw.sh — using current shell exports only."
  echo "hint: cp zenlink-deploy.env.example zenlink-deploy.env && edit, then re-run."
fi

if [[ ! -f "${MCP}/dist/cli.js" ]]; then
  echo "error: missing ${MCP}/dist/cli.js" >&2
  exit 1
fi
if [[ ! -d "${MCP}/node_modules" ]]; then
  echo "error: missing ${MCP}/node_modules (invalid offline bundle)" >&2
  exit 1
fi

HB="${ZENLINK_MCP_OPENCLAW_HOOK_BASE:-}"
HT="${ZENLINK_MCP_OPENCLAW_HOOK_TOKEN:-}"
if [[ -z "${HB// }" || -z "${HT// }" ]]; then
  echo "warning: OpenClaw push disabled until both ZENLINK_MCP_OPENCLAW_HOOK_BASE and ZENLINK_MCP_OPENCLAW_HOOK_TOKEN are set."
  echo "        Fix: add them to zenlink-deploy.env or export before this script; re-run this script after editing."
  echo "        (launchd and other supervisors do not source zenlink-deploy.env — see launchd-zenlink-mcp-daemon.example.plist)"
else
  if [[ -z "${ZENLINK_MCP_OPENCLAW_WAKE_MODE+x}" ]]; then
    export ZENLINK_MCP_OPENCLAW_WAKE_MODE=now
  fi
fi

exec node "${MCP}/scripts/register-openclaw.mjs"
