ZenHeart zenlink-mcp — offline bundle for OpenClaw
===================================================

Contents:
  zenlink-mcp/              MCP package: dist/, node_modules/ (production), package.json
  install-openclaw.sh       Registers stdio MCP (openclaw mcp set; persists hook env into mcp.servers)
  zenlink-deploy.env.example   Copy to zenlink-deploy.env and fill credentials + hook URL/token
  launchd-zenlink-mcp-daemon.example.plist   macOS launchd: duplicate hook env here if you run zenlink-mcp outside OpenClaw
                     (launchd never sources zenlink-deploy.env; OpenClaw-spawned MCP uses mcp.servers.*.env only)

Requirements on the target machine:
  - Node.js 18+
  - openclaw CLI available as "openclaw" (for install-openclaw.sh)
  - No public npm registry required for running MCP (dependencies are bundled under zenlink-mcp/node_modules).

One-command style (after copying env file):
  1. tar xzf zenlink-mcp-offline-v0.12.5.tar.gz
  2. cd zenlink-mcp-offline-v0.12.5
  3. cp zenlink-deploy.env.example zenlink-deploy.env   # edit: agent id, token, hooks; if using --daemon add USE_DAEMON=1 + DAEMON_ADDR_FILE
  4. bash install-openclaw.sh

install-openclaw.sh auto-loads, if present: zenlink-deploy.env then .env (KEY=value exports).

After you edit zenlink-deploy.env (hooks, token, wake), run install-openclaw.sh again so ~/.openclaw/openclaw.json mcp.servers.*.env is updated — that is what OpenClaw-hosted MCP workers read, NOT the .env file alone.

OpenClaw hooks: Gateway must expose POST /hooks/wake with hooks.token matching ZENLINK_MCP_OPENCLAW_HOOK_TOKEN.
register-openclaw.mjs merges hooks.token from openclaw.json when unset; ZENLINK_MCP_OPENCLAW_WAKE_MODE defaults to "now" when base+token are present.
If hooks are missing, run: openclaw hooks init   (then re-run install-openclaw.sh).

Minimal without env file:
  export ZENLINK_AGENT_ID=... ZENLINK_TOKEN=...
  export ZENLINK_MCP_OPENCLAW_HOOK_BASE=... ZENLINK_MCP_OPENCLAW_HOOK_TOKEN=...
  # optional daemon: export ZENLINK_MCP_USE_DAEMON=1 ZENLINK_MCP_DAEMON_ADDR_FILE=~/.openclaw/tmp/zenlink-mcp-daemon.addr
  bash install-openclaw.sh

Manual MCP command (no OpenClaw CLI): point mcp.servers at:
  command: node
  args: [ "<absolute-path>/zenlink-mcp/dist/cli.js" ]
  env: { ZENLINK_AGENT_ID, ZENLINK_TOKEN, ... }

Optional: global CLI from this folder (still offline if node_modules is present):
  npm install -g ./zenlink-mcp --offline --no-audit
