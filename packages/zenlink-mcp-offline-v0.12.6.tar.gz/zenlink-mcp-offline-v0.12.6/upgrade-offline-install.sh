#!/usr/bin/env bash
# Upgrade or first-install the offline tarball into a stable path so launchd / docs need not
# change when the version suffix (v0.12.x) changes.
#
# Usage:
#   bash upgrade-offline-install.sh /path/to/zenlink-mcp-offline-vX.tar.gz
#
# Environment:
#   ZENLINK_MCP_OFFLINE_INSTALL_ROOT  default: $HOME/.openclaw/zenlink-mcp
#
set -euo pipefail
NEW_TAR="${1:?usage: $0 path/to/zenlink-mcp-offline-vX.tar.gz}"
ROOT="${ZENLINK_MCP_OFFLINE_INSTALL_ROOT:-${HOME}/.openclaw/zenlink-mcp}"
CUR="${ROOT}/current"

stop_old_daemon() {
  local sup="${CUR}/zenlink-mcp/scripts/openclaw-zenlink-daemon.mjs"
  [[ -f "$sup" ]] || return 0
  for envf in "${CUR}/zenlink-deploy.env" "${CUR}/.env"; do
    if [[ -f "$envf" ]]; then
      set -a
      # shellcheck disable=SC1090
      source "$envf"
      set +a
      break
    fi
  done
  node "$sup" stop 2>/dev/null || true
}

BK=""
if [[ -d "$CUR" ]]; then
  BK="$(mktemp -d)"
  [[ -f "${CUR}/zenlink-deploy.env" ]] && cp "${CUR}/zenlink-deploy.env" "$BK/"
  [[ -f "${CUR}/.env" ]] && cp "${CUR}/.env" "$BK/"
  stop_old_daemon
  rm -rf "${CUR}.prev"
  mv "$CUR" "${CUR}.prev"
fi

TMP="$(mktemp -d)"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT
tar xzf "$NEW_TAR" -C "$TMP"
SRC=""
for d in "$TMP"/zenlink-mcp-offline-v*; do
  if [[ -d "$d" ]]; then
    SRC="$d"
    break
  fi
done
[[ -n "$SRC" ]] || { echo "error: could not find zenlink-mcp-offline-v* top directory in archive" >&2; exit 1; }

mkdir -p "$ROOT"
cp -a "$SRC" "$CUR"
if [[ -n "$BK" ]]; then
  [[ -f "${BK}/zenlink-deploy.env" ]] && cp "${BK}/zenlink-deploy.env" "${CUR}/"
  [[ -f "${BK}/.env" ]] && cp "${BK}/.env" "${CUR}/"
  rm -rf "$BK"
fi

echo "Installed to: $CUR"
echo "Next:"
echo "  cd \"$CUR\" && bash install-openclaw.sh"
echo "  node \"$CUR/zenlink-mcp/scripts/openclaw-zenlink-daemon.mjs\" start"
echo "  Restart OpenClaw Gateway if needed so MCP workers reload config."
