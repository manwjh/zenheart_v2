ZenHeart zenlink-mcp — offline bundle for OpenClaw
===================================================

Contents:
  zenlink-mcp/              MCP package: dist/, node_modules/ (production), package.json, scripts/
  install-openclaw.sh       Registers stdio MCP (openclaw mcp set; persists hook + daemon forwarding env)
  upgrade-offline-install.sh   Optional: install/upgrade into a fixed directory (~/.openclaw/zenlink-mcp/current)
  zenlink-deploy.env.example   Copy to zenlink-deploy.env and fill credentials + hook URL/token
  launchd-zenlink-mcp-daemon.example.plist   macOS launchd: use absolute paths (see comments; avoid versioned /tmp extract paths)

Requirements on the target machine:
  - Node.js 18+
  - openclaw CLI available as "openclaw" (for install-openclaw.sh)
  - No public npm registry required for running MCP (dependencies are bundled under zenlink-mcp/node_modules).

Recommended fixed path (launchd / upgrades):
  bash upgrade-offline-install.sh zenlink-mcp-offline-v0.12.6.tar.gz
  cd "${HOME}/.openclaw/zenlink-mcp/current" && bash install-openclaw.sh
  node zenlink-mcp/scripts/openclaw-zenlink-daemon.mjs start
  # Restart OpenClaw Gateway if it was already running (so MCP workers reload).

One-command style (extract anywhere):
  1. tar xzf zenlink-mcp-offline-v0.12.6.tar.gz
  2. cd zenlink-mcp-offline-v0.12.6
  3. cp zenlink-deploy.env.example zenlink-deploy.env   # edit: agent id, token, hooks
  4. bash install-openclaw.sh

install-openclaw.sh auto-loads, if present: zenlink-deploy.env then .env (KEY=value exports).
It defaults ZENLINK_MCP_USE_DAEMON=1 and ZENLINK_MCP_DAEMON_ADDR_FILE=${HOME}/.openclaw/tmp/zenlink-mcp-daemon.addr when unset (written into openclaw.json). Opt out: ZENLINK_MCP_USE_DAEMON=0 in zenlink-deploy.env, or ZENLINK_MCP_NO_DEFAULT_DAEMON=1 for a single run.

After you edit zenlink-deploy.env (hooks, token, wake), run install-openclaw.sh again so ~/.openclaw/openclaw.json mcp.servers.*.env is updated — that is what OpenClaw-hosted MCP workers read, NOT the .env file alone.

You must keep zenlink-mcp --daemon running when USE_DAEMON=1: use openclaw-zenlink-daemon.mjs (in zenlink-mcp/scripts/) or launchd.

OpenClaw hooks: Gateway must expose POST /hooks/wake with hooks.token matching ZENLINK_MCP_OPENCLAW_HOOK_TOKEN.
register-openclaw.mjs merges hooks.token from openclaw.json when unset; ZENLINK_MCP_OPENCLAW_WAKE_MODE defaults to "now" when base+token are present.
If hooks are missing, run: openclaw hooks init   (then re-run install-openclaw.sh).

Minimal without env file:
  export ZENLINK_AGENT_ID=... ZENLINK_TOKEN=...
  export ZENLINK_MCP_OPENCLAW_HOOK_BASE=... ZENLINK_MCP_OPENCLAW_HOOK_TOKEN=...
  bash install-openclaw.sh   # still defaults USE_DAEMON + ADDR_FILE into openclaw.json unless NO_DEFAULT_DAEMON=1

Manual MCP command (no OpenClaw CLI): point mcp.servers at:
  command: node
  args: [ "<absolute-path>/zenlink-mcp/dist/cli.js" ]
  env: { ZENLINK_AGENT_ID, ZENLINK_TOKEN, ... }

Optional: global CLI from this folder (still offline if node_modules is present):
  npm install -g ./zenlink-mcp --offline --no-audit
