import { createHash } from "node:crypto";
import { mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";

/** When set with value `1` / `true`, stdio MCP forwards tools to **`zenlink-mcp --daemon`**. */
export function useDaemonStdioMode(): boolean {
  const v = process.env.ZENLINK_MCP_USE_DAEMON;
  return v === "1" || String(v ?? "").toLowerCase() === "true";
}

function agentFingerprint(): string {
  const id =
    process.env.ZENLINK_AGENT_ID ??
    process.env.ZENHEART_AGENT_ID ??
    process.env.ZENHEART_V2_AGENT_ID ??
    "";
  const h = createHash("sha256").update(id || "unset").digest("hex");
  return h.slice(0, 24);
}

/**
 * Addr file (**`host:port`**, one line) used by **`--daemon`** (writes) and stdio (**reads**).
 * Override via **`ZENLINK_MCP_DAEMON_ADDR_FILE`**, else **`${tmpdir()}/zenlink-mcp-${hash}.addr`** (hash from agent id env).
 */
export function defaultDaemonAddrFile(): string {
  const fromEnv = process.env.ZENLINK_MCP_DAEMON_ADDR_FILE?.trim();
  if (fromEnv) {
    const parent = dirname(fromEnv);
    try {
      mkdirSync(parent, { recursive: true });
    } catch {
      /* ignore mkdir failure; daemon write will surface */
    }
    return fromEnv;
  }
  return join(tmpdir(), `zenlink-mcp-${agentFingerprint()}.addr`);
}

export function assertAgentEnvLoaded(): void {
  const aid =
    process.env.ZENLINK_AGENT_ID ??
    process.env.ZENHEART_AGENT_ID ??
    process.env.ZENHEART_V2_AGENT_ID;
  const tok =
    process.env.ZENLINK_TOKEN ??
    process.env.ZENHEART_TOKEN ??
    process.env.ZENHEART_V2_TOKEN;
  if (!aid?.trim() || !tok?.trim()) {
    throw new Error(
      "zenlink-mcp daemon: missing ZENLINK_AGENT_ID / ZENLINK_TOKEN (or ZENHEART_* / ZENHEART_V2_*)",
    );
  }
}

/**
 * **`ZENLINK_MCP_DAEMON_INVOKE_TIMEOUT_MS`** — max wait per tool **`invoke`** on the stdio → daemon IPC.
 * **`0` / omit** = unlimited (recommended only while debugging timeouts).
 *
 * Defaults to **900000** (15 minutes) — large Router + ZenHeart WS stalls should stay under this in production.
 */
export function readDaemonInvokeTimeoutMs(): number {
  const raw = process.env["ZENLINK_MCP_DAEMON_INVOKE_TIMEOUT_MS"];
  if (raw === undefined || raw === "") {
    return 900_000;
  }
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) {
    throw new Error(
      `ZENLINK_MCP_DAEMON_INVOKE_TIMEOUT_MS must be non-negative (${raw})`,
    );
  }
  return Math.floor(n);
}
