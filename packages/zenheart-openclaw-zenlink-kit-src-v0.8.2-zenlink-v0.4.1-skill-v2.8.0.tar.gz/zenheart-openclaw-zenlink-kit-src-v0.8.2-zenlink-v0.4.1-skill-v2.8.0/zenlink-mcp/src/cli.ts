import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const argv = process.argv.slice(2);
const arg0 = argv[0];

if (arg0 === "--help" || arg0 === "-h") {
  console.log(`zenlink-mcp — ZenHeart MCP server (stdio JSON-RPC).

Usage:
  zenlink-mcp                 Run MCP over stdin/stdout
  zenlink-mcp --daemon      Long-lived: one ZenHeart WebSocket; writes addr file + TCP localhost
  zenlink-mcp --help        Show this text
  zenlink-mcp --version     Print package version

Environment (required): ZENLINK_AGENT_ID and ZENLINK_TOKEN (or ZENHEART_* / ZENHEART_V2_* aliases).
Optional transport: ZENLINK_HOST, ZENLINK_USE_TLS, ZENLINK_MCP_WS_TIMEOUT_MS,
  ZENLINK_MCP_LONG_LIVED (=0|false to disable default long-lived reconnect), ZENLINK_MCP_INBOUND_QUEUE_MAX (default 500; 0 disables inbound FIFO).
Daemon forwarding (stdin MCP peers share ONE session): ZENLINK_MCP_USE_DAEMON=1 (+ optional ZENLINK_MCP_DAEMON_ADDR_FILE — must match daemon). Start daemon first: zenlink-mcp --daemon
`);
  process.exit(0);
}

if (arg0 === "--version" || arg0 === "-v") {
  const pkgPath = join(dirname(fileURLToPath(import.meta.url)), "..", "package.json");
  const ver = JSON.parse(readFileSync(pkgPath, "utf8")).version ?? "unknown";
  console.log(String(ver));
  process.exit(0);
}

if (arg0 === "--daemon") {
  const { runZenlinkDaemon } = await import("./daemon.js");
  await runZenlinkDaemon();
} else {
  const { runStdioServer } = await import("./server.js");
  try {
    await runStdioServer();
  } catch (e) {
    console.error(e instanceof Error ? e.message : e);
    process.exit(1);
  }
}
