ZenHeart zenlink-mcp — offline bundle for OpenClaw (Linux)
==========================================================

Bundle id: openclaw-linux  (target: OpenClaw (Linux); Node 18+)

Contents:
  install-zenlink-mcp-openclaw-linux-v0.13.27.sh   Self-extracting one-command installer (distributed beside this tarball)
  zenlink-bundle.manifest.json   Machine-readable contract: artifacts, report prefixes, schemas (read first for autonomous installs)
  AGENT_PLAYBOOK.md              Concise playbook for LLM-driven install / upgrade / verification
  pipeline-phase-emit.mjs        Streams ZENLINK_*_PHASE_JSON lines (install + upgrade); also under zenlink-mcp/scripts/
  zenlink-mcp/              MCP package: dist/, node_modules/ (production), package.json, scripts/
  install-openclaw.sh       Registers stdio MCP (openclaw mcp set; persists hook + daemon forwarding env)
  upgrade-offline-install.sh   Optional: install/upgrade into a fixed directory (~/.openclaw/zenlink-mcp/current)
  zenlink-deploy.env.example   Credentials + hooks (agent: inject via env or write file before install-openclaw.sh)

Requirements on the target machine:
  - Node.js 18+
  - openclaw CLI available as "openclaw" (for install-openclaw.sh)
  - No public npm registry required for running MCP (dependencies are bundled under zenlink-mcp/node_modules).

Recommended fixed path (supervisor / upgrades):
  bash install-zenlink-mcp-openclaw-linux-v0.13.27.sh
  # Self-extracting installer: extracts this bundle to a temp dir, then runs upgrade-offline-install.sh.
  # If you only have the tarball:
  bash upgrade-offline-install.sh zenlink-mcp-openclaw-linux-v0.13.27.tar.gz
  # Default: upgrade script runs install-openclaw.sh, starts daemon, restarts Gateway, and runs doctor.

Agent install sequence (preferred):
  1. If you were given install-zenlink-mcp-openclaw-linux-v0.13.27.sh, run: bash install-zenlink-mcp-openclaw-linux-v0.13.27.sh
  2. Parse stderr for ZENLINK_UPGRADE_REPORT_JSON=... and nested install report lines.
  3. Verify daemon_started, gateway_restarted, and zenlink_doctor checks.

Fallback manual sequence (tarball only):
  1. tar xzf zenlink-mcp-openclaw-linux-v0.13.27.tar.gz && cd zenlink-mcp-openclaw-linux-v0.13.27
  2. Read zenlink-bundle.manifest.json (contract)
  3. Ensure zenlink-deploy.env or exported ZENLINK_* (see AGENT_PLAYBOOK.md)
  4. Prefer: bash upgrade-offline-install.sh ../zenlink-mcp-openclaw-linux-v0.13.27.tar.gz
     Manual/debug fallback: bash install-openclaw.sh
  5. Parse stderr for ZENLINK_INSTALL_REPORT_JSON=... (exit code must match exit_code; checks[])
  6. Verify daemon_started and gateway_restarted checks, then verify zenlink_status in OpenClaw.

Autonomous agents: follow AGENT_PLAYBOOK.md; use manifest machine_contracts for exact stderr prefixes.

Install / upgrade JSON lines:
  ZENLINK_INSTALL_REPORT_JSON=  (register-openclaw / install-openclaw; disable ZENLINK_MCP_INSTALL_REPORT=0)
  ZENLINK_UPGRADE_REPORT_JSON=  (upgrade-offline-install.sh; disable ZENLINK_MCP_UPGRADE_REPORT=0)
  ZENLINK_INSTALL_PHASE_JSON=   (many lines during install-openclaw.sh + register-openclaw.mjs; zenlink_pipeline_phase/v1; disable ZENLINK_MCP_INSTALL_PHASE_EVENTS=0)
  ZENLINK_UPGRADE_PHASE_JSON=   (during upgrade-offline-install.sh; disable ZENLINK_MCP_UPGRADE_PHASE_EVENTS=0)

install-openclaw.sh auto-loads, if present: zenlink-deploy.env then .env (KEY=value exports).
It defaults ZENLINK_MCP_USE_DAEMON=1 and ZENLINK_MCP_DAEMON_ADDR_FILE=${HOME}/.openclaw/tmp/zenlink-mcp-daemon.addr when unset (written into openclaw.json). Opt out: ZENLINK_MCP_USE_DAEMON=0 in zenlink-deploy.env, or export ZENLINK_MCP_NO_DEFAULT_DAEMON=1 for a single run.

After changing persisted hook/daemon env, re-run install-openclaw.sh so ~/.openclaw/openclaw.json mcp.servers.*.env updates — that is what OpenClaw MCP workers read.

You must keep zenlink-mcp --daemon running when USE_DAEMON=1: use openclaw-zenlink-daemon.mjs (foreground), systemd, or supervisord — see your distro docs.

OpenClaw hooks: Gateway must expose POST /hooks/agent with hooks.token matching ZENLINK_MCP_OPENCLAW_HOOK_TOKEN.
register-openclaw.mjs merges hooks.token from openclaw.json when unset; ZENLINK_MCP_OPENCLAW_WAKE_MODE defaults to "now" when base+token are present, and ZENLINK_MCP_OPENCLAW_SESSION_KEY defaults to hook:zenheart-main for stable agent hook routing.
If hooks are missing: openclaw hooks init (then re-run install-openclaw.sh).

Minimal shell exports (no zenlink-deploy.env file):
  export ZENLINK_AGENT_ID=... ZENLINK_TOKEN=...
  export ZENLINK_MCP_OPENCLAW_HOOK_BASE=... ZENLINK_MCP_OPENCLAW_HOOK_TOKEN=...
  bash install-openclaw.sh

Manual MCP command (no OpenClaw CLI): point mcp.servers at:
  command: node
  args: [ "<absolute-path>/zenlink-mcp/dist/cli.js" ]
  env: { ZENLINK_AGENT_ID, ZENLINK_TOKEN, ... }

Node command used by install/register:
  - Set ZENLINK_MCP_NODE_COMMAND to force a specific Node binary.
  - Otherwise register-openclaw.mjs prefers "command -v node" (stable Homebrew symlink such as /opt/homebrew/bin/node)
    before falling back to the current process executable.

Optional: global CLI from this folder (still offline if node_modules is present):
  npm install -g ./zenlink-mcp --offline --no-audit
